<!doctype html>
<html lang="en">
  <head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  
  <style>
*{
  margin: 0;
  padding: 0;
}
body{
  background:blue;
}
  </style>
  </head>
  <body>
   <!-- Status message -->
 

  <div class="container my-4">

  <?php  


  
        if(!empty($success_msg)){ 
            echo '<div class="alert alert-primary" role="alert">'
           
          .'Success! ' .$success_msg.'</div>'; 
        }elseif(!empty($error_msg)){ 
            echo '<div class="alert alert-primary" role="alert">'.'Wraning! '.$error_msg.'</div>'; 
        } 
    ?>

  <div class="card m-auto" >
  <div class="card-body">
    <h5 class="card-title">Update User</h5>
    <hr>
    <form action="<?php echo base_url('admin/update')."?uid=".$id;  ?>" method="post" enctype="multipart/form-data">
    
    <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Name</label>
    <input type="text" class="form-control" aria-describedby="emailHelp" name="name" value="<?php echo $user[0]['name'];  ?>">
    <span class="text-danger"><?php echo form_error('name');  ?>
  </div>

  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Mobile</label>
    <input type="test" class="form-control" aria-describedby="emailHelp" name="mobile" value="<?php echo $user[0]['mobile'];  ?>">
    <span class="text-danger"><?php echo form_error('mobile');  ?>

  </div>

  <div class="mb-3">
                                    <label class="form-label align">Image</label>
                                    <input type="file" name="userfile" class="form-control" id="inputEmail4">
<br>
                                    <img src="<?php echo base_url() ?>uploads/<?php echo $user[0]['image'] ?>" width="150px">

                                </div>
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Email address</label>
    <input type="email" class="form-control" aria-describedby="emailHelp" name="email" value="<?php echo $user[0]['email'];  ?>">
    <span class="text-danger"><?php echo form_error('email');  ?>

  </div>

  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label"><b>Gender</b> </label>
    <div class="form-check">
  <input class="form-check-input" type="radio" name="gender" value="male">
  <label class="form-check-label">
Male</label>
</div>
<div class="form-check">
  <input class="form-check-input" type="radio" name="gender" value="female">
  <label class="form-check-label" for="exampleRadios2">
Female</label>
</div>
<div class="form-check">
  <input class="form-check-input" type="radio" name="gender" value="other">
  <label class="form-check-label">
Other  </label>
</div>

<div class="mb-3">
    <label for="exampleInputPassword1" class="form-label"><b>Date Of Birth</b>  </label>
    <input type="date" class="form-control" name="dob">

  </div>

  <div class="mb-3">    
    <label for="exampleInputPassword1" class="form-label"><b>City</b> </label>

  <select class="form-select w-100 form-control" aria-label="Default select example" name="city">
  <option value="1">Delhi</option>
  <option value="2">Noida</option>
  <option value="3">Ghaziabad</option>
</select>  
</div>
  
  <button type="submit" class="btn btn-primary" name="submit">Update</button>

  </div>
</div>

  </div>




    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>