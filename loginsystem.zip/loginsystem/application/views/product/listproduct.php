<!doctype html>
<html lang="en">
  <head>
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body>

  <div class="container my-4">

<a href="<?php echo base_url('product/addProduct'); ?>" class="btn btn-primary my-2">Add Product</a>

<?php if($responce = $this->session->flashdata('Successfully')): ?>
  
  <div class="box-header">
    <div class="col-lg-6">
       <div class="alert alert-success"><?php echo $responce;?></div>
    </div>
  </div>

<?php endif;?>

<?php if($responce = $this->session->flashdata('error')):?>

<div class="box-header">
    <div class="col-lg-6">
       <div class="alert alert-danger w-100"><?php echo $responce;?></div>
    </div>
  </div>
  
<?php endif;?>

<table class="table">
<thead>
<tr>
  <th scope="col">#</th>
  <th scope="col">Title</th>
  <th scope="col">Decription</th>
  <th scope="col">Image</th>
  <th scope="col">Status</th>
  <th scope="col">Action</th>


</tr>
</thead>
<tbody>
<?php  $i=1;
foreach ($products as $value) {
?>    
<tr>
  <td><?php  echo $i; ?></td>
  <td><?php  echo $value['title']; ?></td>
  <td><?php  echo $value['description']; ?></td>
  <td>    <img src="<?php echo base_url() ?>uploads/product/<?php echo $value['image']; ?>" width="70">
</td>

<?php  if ($value['status']=="1") {
   $status="Active";
  }
   else if ($value['status']=="0"){
  
   $status="Deactive";
}
?>
  <td><a href="" class="btn btn-success"><?php  echo $status;  ?></a></td>

  <td>
    <a href="<?php echo base_url('product/edit')."?id=".$value['id'];   ?>" class="btn btn-primary">Update</a>
<a href="<?php echo base_url('product/delete')."?id=".$value['id'];   ?>" class="btn btn-danger">Delete</a>
  </td>


</tr>
<?php $i++; } ?>
</tbody>
</table>

<?php echo $links; 
       ?>

</div>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>