<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_model extends CI_model {

function insertData($insertData = array())
    {
        $result = $this->db->insert('users', $insertData);
        if ($result) {
            return $this->db->insert_id();
        } else {
            return false;
        }
    }

    function getRows($email,$pass){ 
        $this->db->where('email',$email);
        $this->db->where('pass',$pass);

        $getdata=$this->db->get('users');
        // print_r($getdata->result_array());
        // die;
        if ($getdata) {
            return $getdata->result_array();
        }
        else {
            return "not fond";
        }
    }

    function getRow($id){ 
       
        $getdata=$this->db->where('id',$id)->get('users');
        // print_r($getdata);
        // die;
        if ($getdata) {
            return $getdata->result_array();
        }
        else {
            return "not fond";
        }
}

public function updateuser($updatedata,$id)
{

  
    $this->db->where('id', $id);
    if ($this->db->update('users', $updatedata)) {
        return true;
    }else{
        return false;
    }

  

}

}
?>