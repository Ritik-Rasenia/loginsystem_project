<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product_model extends CI_model {

    function insertData($insertData = array())
    {
        $result = $this->db->insert('product', $insertData);
        if ($result) {
            return $this->db->insert_id();
        } else {
            return false;
        }
    }


    function getData($limit,$start){ 
    

        $this->db->limit($start,$limit);
        $query = $this->db->get('product');

      return $query->result_array();
    }

public function editData($id)

{

    $this->db->where('id',$id);
    $res= $this->db->get('product');
    if ($res) {
        return $res->result_array();

    }else{
     return false;
    }
}


public function updateData($id,$updateData){
    $this->db->where('id',$id);
       $res= $this->db->update('product',$updateData);
       if ($res) {
        return true;

    }
    else {
        return "not fond";
    }

}

    public function deleteData($id){
        $this->db->where('id',$id);
       $res= $this->db->delete('product');
       if ($res) {
        return true;

    }
    else {
        return "not fond";
    }
    }

    public function get_count() {
        return $this->db->count_all('product');
    }

}?>