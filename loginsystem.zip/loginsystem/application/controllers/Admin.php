<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {


function __construct() { 
        parent::__construct(); 
         
        // Load form validation ibrary & user model 
        $this->load->library('form_validation'); 
         
        // User login status 
        $this->isUserLoggedIn = $this->session->userdata('isUserLoggedIn'); 
    } 

 public function index(){ 
        if($this->isUserLoggedIn){ 
            redirect('admin/account'); 
        }else{ 
            redirect('admin/login'); 
        } 
    } 

public function login_view(){

    $this->load->view('admin/login');


}
public function signup_view(){
    
    $this->load->view('admin/signup');
}


public function signup(){ 
    $data = $userData = array(); 
     
    // If registration request is submitted 
   
        $this->form_validation->set_rules('name', 'Name', 'required'); 
        $this->form_validation->set_rules('mobile', 'Mobile', 'required'); 
        $this->form_validation->set_rules('dob', 'Date Of Birth', 'required'); 
        $this->form_validation->set_rules('city', 'City', 'required'); 
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email'); 
        $this->form_validation->set_rules('pass', 'password', 'required'); 
        $this->form_validation->set_rules('cpass', 'confirm password', 'required|matches[pass]'); 

       
			$config['upload_path'] = "./uploads/";
			$config['allowed_types']        = 'gif|jpg|png';
			$config['max_size']             = 100;
			$config['max_width']            = 1024;
			$config['max_height']           = 768;

			$this->load->library('upload', $config);
			$this->upload->initialize($config);

			if ( ! $this->upload->do_upload('userfile'))
			{
					$error = array('error' => $this->upload->display_errors());

			}
			else
			{
					$datafile = $this->upload->data();
					

			}
// print_r($error);
			$file = $datafile['file_name'];
            // echo $file;
            // die;
        
        $userData = array( 

            'name' => strip_tags($this->input->post('name')), 
            'mobile' => strip_tags($this->input->post('mobile')), 
            'email' => strip_tags($this->input->post('email')), 
            'pass' => md5($this->input->post('pass')), 
            'image' => $file,
            'dob' => $this->input->post('dob'), 
            'gender' => $this->input->post('gender'), 
            'city' => $this->input->post('city')

         
        ); 

        if($this->form_validation->run() == true){ 
            $insert = $this->Admin_model->insertData($userData); 

            if($insert){ 
                $this->session->set_userdata('success_msg', 'Your account registration has been successful. Please login to your account.'); 
                redirect('admin/login'); 
            }else{ 
                $data['error_msg'] = 'Some problems occured, please try again.'; 
            } 
        }else{ 
            $data['error_msg'] = 'Please fill all the mandatory fields.'; 
        } 
    
     
    // Load view
$this->load->view('admin/signup', $data); 

} 

public function login(){ 
    $data = array(); 

    if($this->session->userdata('success_msg')){ 
        $data['success_msg'] = $this->session->userdata('success_msg'); 
        $this->session->unset_userdata('success_msg'); 
    } 
    if($this->session->userdata('error_msg')){ 
        $data['error_msg'] = $this->session->userdata('error_msg'); 
        $this->session->unset_userdata('error_msg'); 
    }

     // If login request submitted 
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email'); 
        $this->form_validation->set_rules('pass', 'password', 'required'); 
         
        if($this->form_validation->run() == true){ 
           
             
                    $email= $this->input->post('email'); 
                    $pass = md5($this->input->post('pass'));
                  
         
            $checkLogin = $this->Admin_model->getRows($email,$pass); 
      

            if($checkLogin){ 
                $this->session->set_userdata('isUserLoggedIn', TRUE); 
                $this->session->set_userdata('userId', $checkLogin[0]['id']); 
            
                redirect('admin/account'); 
            }
            else{ 
                $data['error_msg'] = 'Wrong email or password, please try again.'; 
            } 
        }else{ 
            // $data['error_msg'] = 'Please fill all the mandatory fields.'; 
        } 
    
     
    // Load view 
    $this->load->view('admin/login', $data); 
} 

public function logout(){ 
   

    $this->session->unset_userdata('isUserLoggedIn'); 
    $this->session->unset_userdata('userId'); 
    $this->session->sess_destroy(); 
   redirect('admin/login'); 
} 

public function account(){ 
    $data = array(); 
    if($this->isUserLoggedIn){ 
      $id = $this->session->userdata('userId'); 
    //   echo $id;
    //   die;
      $data['user'] = $this->Admin_model->getRow($id); 
        
   
         
        // Pass the user data and load view 
        $this->load->view('temalate/header', $data); 
        $this->load->view('admin/welcome', $data); 
        $this->load->view('temalate/footer', $data); 

    }else{ 
        redirect('admin/login'); 
    } 
} 


public function edit(){
    $id=$_GET['id'];
    $data['id']=$_GET['id'];
    $data['user'] = $this->Admin_model->getRow($id); 
    $this->load->view('admin/edituser',$data);
}

public function update(){

    $uid=$_GET['uid'];

    $config['upload_path'] = "./uploads/";
			$config['allowed_types']        = 'gif|jpg|png';
			$config['max_size']             = 100;
			$config['max_width']            = 1024;
			$config['max_height']           = 768;

			$this->load->library('upload', $config);
			$this->upload->initialize($config);

			if ( ! $this->upload->do_upload('userfile'))
			{
					$error = array('error' => $this->upload->display_errors());

			}
			else
			{
					$datafile = $this->upload->data();
					

			}
// print_r($error);
			$file = $datafile['file_name'];
            // echo $file;
            // die;


    $updateData = array( 

        'name' => strip_tags($this->input->post('name')), 
        'mobile' => strip_tags($this->input->post('mobile')), 
        'email' => strip_tags($this->input->post('email')), 
        'image' => $file,
        'dob' => $this->input->post('dob'), 
        'gender' => $this->input->post('gender'), 
        'city' => $this->input->post('city')

     
    ); 

  

  $check=$this->Admin_model->updateuser($updateData,$uid);
if ($check) {
    
    redirect('admin/account'); 

  }
  else{
    redirect('admin/login'); 

  }

}


public function profile(){

    if($this->isUserLoggedIn){ 
        $id = $this->session->userdata('userId'); 
      //   echo $id;
      //   die;
        $data['user'] = $this->Admin_model->getRow($id); 
          
     
           
          // Pass the user data and load view 
          $this->load->view('temalate/header', $data); 

          $this->load->view('admin/account', $data); 
          $this->load->view('temalate/footer', $data); 

      }
}

public function about(){
    $this->load->view('temalate/header'); 

    $this->load->view('about'); 
    $this->load->view('temalate/footer'); 

}

public function contact(){
    $this->load->view('temalate/header'); 

    $this->load->view('contact'); 
    $this->load->view('temalate/footer'); 

}

public function sendmail(){

    //contact value
    $name = $this->input->post('name');
    $email = $this->input->post('email');
    $msg = $this->input->post('msg');
    
       // Load PHPMailer library
        $this->load->library('phpmailer_lib');
        
        // PHPMailer object
        $mail = $this->phpmailer_lib->load();
        
        $mail->isSMTP();
        $mail->Host     = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'ritikrasenia1234@gmail.com';
        $mail->Password = '';
        $mail->SMTPSecure = 'ssl';
        $mail->Port     = 465;
        
        $mail->setFrom('ritikrasenia@gmail.com', 'Ritik Rasenia');
        $mail->addAddress($email);
        
      
        $mail->addReplyTo('ritikrasenia1234@gmail.com');
         
        // Email subject
        $mail->Subject = 'Send Email via SMTP using PHPMailer in CodeIgniter';
        
        // Set email format to HTML
        $mail->isHTML(true);
        
            $mail->Subject = $name;
            $mail->Body = $msg;

        
        // Send email
        if(!$mail->send()){
            $data['msg'] = 'Message could not be sent.';
            $data['msg'] = 'Mailer Error: ' . $mail->ErrorInfo;
        }else{
            $data['msg'] = 'Message has been sent';
        }

        print_r($data);
      
   
    $this->load->view('temalate/header'); 
    $this->load->view('thanks'); 
    $this->load->view('temalate/footer'); 
}

}
?>