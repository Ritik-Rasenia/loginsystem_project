<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product extends CI_Controller {

   function __construct() { 
      parent::__construct(); 
       
      // Load form validation ibrary & user model 
      $this->load->library('form_validation'); 
              $this->load->library("pagination");

       
      
  } 
     public function listProduct(){
      
 
      $config = array();
      $config["base_url"] = base_url('product/listproduct');
      $config["total_rows"] = $this->Product_model->get_count();
      $config["per_page"] = 3;
      $config["uri_segment"] = 3;

 
    $config['full_tag_open'] = '<ul class="pagination justify-content-center">';        
    $config['full_tag_close'] = '</ul>';        
    $config['first_link'] = 'First';        
    $config['last_link'] = 'Last';        
    $config['first_tag_open'] = '<li class="page-item"><span class="page-link">';        
    $config['first_tag_close'] = '</span></li>';        
    $config['prev_link'] = '&laquo';        
    $config['prev_tag_open'] = '<li class="page-item"><span class="page-link">';        
    $config['prev_tag_close'] = '</span></li>';        
    $config['next_link'] = '&raquo';        
    $config['next_tag_open'] = '<li class="page-item"><span class="page-link">';        
    $config['next_tag_close'] = '</span></li>';        
    $config['last_tag_open'] = '<li class="page-item"><span class="page-link">';        
    $config['last_tag_close'] = '</span></li>';        
    $config['cur_tag_open'] = '<li class="page-item active"><a class="page-link" href="#">';        
    $config['cur_tag_close'] = '</a></li>';        
    $config['num_tag_open'] = '<li class="page-item"><span class="page-link">';        
    $config['num_tag_close'] = '</span></li>';

      $this->pagination->initialize($config);

      $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;

      $data["links"] = $this->pagination->create_links();
      $data['products'] = $this->Product_model->getData($page,$config["per_page"],);


        $this->load->view('temalate/header');
        $this->load->view('product/listproduct',$data);
        $this->load->view('temalate/footer');

     }

     public function addProduct(){

        $this->form_validation->set_rules('title', 'Title', 'required'); 
        $this->form_validation->set_rules('desc', 'Description', 'required'); 

        $config['upload_path'] = "./uploads/product";
			$config['allowed_types']        = 'gif|jpg|png';
			$config['max_size']             = 100;
			$config['max_width']            = 1024;
			$config['max_height']           = 768;

			$this->load->library('upload', $config);
			$this->upload->initialize($config);

			if ( ! $this->upload->do_upload('userfile'))
			{
					$error = array('error' => $this->upload->display_errors());

			}
			else
			{
					$datafile = $this->upload->data();
					

			}
// print_r($error);
			$file = $datafile['file_name'];
          
         $productData = array( 

            'title' => strip_tags($this->input->post('title')), 
            'description' => strip_tags($this->input->post('desc')), 
              'image' => $file
         ); 

         if($this->form_validation->run() == true){ 
            $insert = $this->Product_model->insertData($productData); 

            if($insert){ 

                $this->session->set_userdata('Successfully', 'Product has been Inserted successfully.'); 
                redirect('product/listProduct'); 

            }else{ 

                $data['error_msg'] = 'Some problems occured, please try again.'; 

            } 
        }
      
      $this->load->view('temalate/header');
      $this->load->view('product/addProduct',$data);
      $this->load->view('temalate/footer');

   }


   public function edit(){
      $id=$_GET['id'];
      $data['user'] = $this->Product_model->editData($id);
     
      
      $this->load->view('temalate/header');
      $this->load->view('product/editproduct',$data);
      $this->load->view('temalate/footer');

   }

public function updateProduct(){
   
   $id=$_GET['id'];

   $this->form_validation->set_rules('title', 'Title', 'required'); 
   $this->form_validation->set_rules('desc', 'Description', 'required'); 

   $config['upload_path'] = "./uploads/product";
    $config['allowed_types']        = 'gif|jpg|png';
    $config['max_size']             = 100;
    $config['max_width']            = 1024;
    $config['max_height']           = 768;

    $this->load->library('upload', $config);
    $this->upload->initialize($config);

    if ( ! $this->upload->do_upload('userfile'))
    {
          $error = array('error' => $this->upload->display_errors());

    }
    else
    {
          $datafile = $this->upload->data();
          

    }
// print_r($error);
    $file = $datafile['file_name'];
     
    $productData = array( 

       'title' => strip_tags($this->input->post('title')), 
       'description' => strip_tags($this->input->post('desc')), 
         'image' => $file
    ); 

    if($this->form_validation->run() == true){ 
       $update = $this->Product_model->updateData($id,$productData); 

       if($update){ 

           $this->session->set_userdata('Successfully', 'Product has been Updated successfully.'); 
           redirect('product/listProduct'); 

       }else{ 

           $data['error_msg'] = 'Some problems occured, please try again.'; 
       } 
   }
 
 $this->load->view('temalate/header');
 $this->load->view('product/editproduct',$data);
 $this->load->view('temalate/footer');


}

public function delete(){

   $id=$_GET['id'];
   $deleteData = $this->Product_model->deleteData($id);

   if($deleteData){ 
      $this->session->set_userdata('Successfully', 'Product has been Deleted successfully.'); 
      redirect('product/listProduct'); 

  }
  else{ 

      $data['error_msg'] = 'Some problems occured, please try again.'; 
      
  }


   $this->load->view('temalate/header');
   $this->load->view('product/listproduct',$data);
   $this->load->view('temalate/footer');

}
}
?>