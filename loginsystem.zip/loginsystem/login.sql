-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 30, 2023 at 12:35 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `login`
--

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(3) NOT NULL,
  `title` varchar(150) NOT NULL,
  `description` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `title`, `description`, `status`, `image`) VALUES
(12, 'watch', 'watch', 0, 'download_(3)7.jpg'),
(13, 'headphone', 'headphone', 1, '51Y7SIK68KL__SX522_1.jpg'),
(14, 'laptop', 'laptop', 1, 'download_(5).jpg'),
(15, 'webcam', 'webcam', 1, '61HfJn05shL__SX522_3.jpg'),
(16, 'home theater system', 'home theater system', 1, '71Ffh7BAS5S__SX522_.jpg'),
(17, 'camara', 'camara', 1, 'download_(7).jpg'),
(18, 't shirt', 't shirt', 1, 'images_(3).jpg'),
(19, 'iphone 15 pro max', 'iphone 15 pro max', 1, '61BGE6iu4AL__SX679_2.jpg'),
(20, 'tab', 'realme tab', 1, 'download_(8).jpg'),
(21, 'nackalace', 'nackalace', 1, '91rGvd05X+L__UY625_.jpg'),
(22, 'tv', 'tv', 1, 'download_(10).jpg'),
(23, 'Realme phone', 'Realme phone', 1, 'images3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(3) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `dob` date DEFAULT NULL,
  `gender` varchar(50) NOT NULL,
  `city` int(3) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `image` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `dob`, `gender`, `city`, `pass`, `mobile`, `image`, `status`) VALUES
(5, 'Ritik', 'ritik@mail.com', '2001-03-02', 'male', 2, '202cb962ac59075b964b07152d234b70', '9368295450', 'download5.jpg', 1),
(6, 'Rajni', 'rajni@mail.com', '2023-03-01', 'female', 3, 'a5a7158118e59ee590424b55bb9aed17', '9368292323', 'download_(1)3.jpg', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
